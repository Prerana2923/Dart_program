void main(){
int empId = 20;
print("My employee id is $empId");
}