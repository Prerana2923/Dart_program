void main(){
String firstName = "Incubators";
print("My name is $firstName and length is: ${firstName.length}");
}