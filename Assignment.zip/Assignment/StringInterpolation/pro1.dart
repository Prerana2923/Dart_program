void main(){
int empId = 20;
print(empId);
}