void main(){

  int x =20;

  if(x>=16 && x%2==0){
    print("Correct number");

  }
  else{
    print("Incorrect number");
  }
}