void main() {
  double percentage = 80.0; // Input value for 12th percentage
  double cgpa = 7.7; // Input value for CGPA

  if (percentage >= 70.0 && cgpa >= 7.0) {
    print('You are eligible');
  } else {
    print('You are not eligible');
  }
}
