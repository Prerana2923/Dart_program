void main() {
  int x = 20;
  int remainder = x % 3;

  if (remainder == 2) {
    print("Remainder is equal to 2");
  } else if (remainder < 2) {
    print("Remainder is less than 2");
  } else {
    print("Remainder is greater than 2");
  }
}
