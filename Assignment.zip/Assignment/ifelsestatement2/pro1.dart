void main(){
int ramSize = 8;

if(ramSize<=4){
  print("can't run a project");
}
else{
     print("can run a flutter project");
}
}