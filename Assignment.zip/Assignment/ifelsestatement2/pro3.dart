void main() {
  int x = 45;
  if (x >= 30 && x <= 50) {
    print("Number is in correct range");
  } else {
    print("Invalid Number");
  }
}
