void main() {
  // Loop through numbers from 1 to 50
  for (int i = 1; i <= 50; i++) {
    // Check if the number is odd
    if (i % 2 != 0) {
      print(i); // Print the odd number
    }
  }
}
