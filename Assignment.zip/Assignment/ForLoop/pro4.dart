void main() {
  // Loop through numbers from 1 to 100
  for (int i = 1; i <= 100; i++) {
    // Check if the number is even
    if (i % 2 == 0) {
      print(i); // Print the even number
    }
  }
}

