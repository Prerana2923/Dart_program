void main() {
  int start = 100; // First 3-digit number
  int count = 10; // Number of 3-digit numbers to print

  // Loop to print the first ten 3-digit numbers
  for (int i = start; i < start + count; i++) {
    print(i);
  }
}
