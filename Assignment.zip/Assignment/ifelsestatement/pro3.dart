void main(){

  int age = 19;

  if(age>=18){

    print("sage  you can cast a vote");
  }else{
     print("sage  you can't cast a vote");

  }
}