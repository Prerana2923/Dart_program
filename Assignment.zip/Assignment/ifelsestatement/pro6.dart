void main(){

  var x =6;
   if(x==0){
    print("zero");
  }
  if(x==1){
    print("one");
  }
  else if(x==2){
    print("two");
  }
   else if(x==3){
    print("three");
  }
   else if(x==4){
    print("four");
  }
   else if(x==5){
    print("five");
  }
  else{

    print("$x is greater than 5");
  }
}