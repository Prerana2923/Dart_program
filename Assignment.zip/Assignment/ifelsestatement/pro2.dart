void main(){

  var x = 5;

  if(x<=10){
    print("$x is less than 10");
  }
}