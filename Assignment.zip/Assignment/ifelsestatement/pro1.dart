void main(){

  var x = 10;
  
  if(x%2==0){
    print("$x Is a Even Number");

  }else{
    print( "$x is not even number ");
  }
}