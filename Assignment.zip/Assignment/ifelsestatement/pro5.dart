void main(){

  var c = "A";

  if (c=="A"|| c =="E"|| c =="I"|| c=="O" ||c=="U"){

    print ("$c is a vowel");
  }else{
    print("$c is a consonant");
  }
}